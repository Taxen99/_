- modify spinning circle text to be unique per spinner

- modify instructions in 1222255555 to be accurate!